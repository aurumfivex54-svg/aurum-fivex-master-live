import os, json, sqlite3, secrets, hashlib, hmac, time
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
from dotenv import load_dotenv
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.middleware.sessions import SessionMiddleware
from pywebpush import webpush, WebPushException

load_dotenv()
BASE=Path(__file__).resolve().parent
DB=Path(os.getenv('DB_PATH','./data/signals.db')).resolve()
DB.parent.mkdir(parents=True,exist_ok=True)
PASSWORD=os.getenv('APP_PASSWORD','')
TOKEN=os.getenv('WEBHOOK_TOKEN','')
SECRET=os.getenv('SESSION_SECRET','')
if any(len(x)<24 for x in (PASSWORD,TOKEN,SECRET)):
    raise RuntimeError('Set APP_PASSWORD, WEBHOOK_TOKEN, SESSION_SECRET to distinct 24+ character secrets in .env')
app=FastAPI(title='AURUM FIVEX MASTER LIVE')
app.add_middleware(SessionMiddleware, secret_key=SECRET, https_only=os.getenv('COOKIE_SECURE','true').lower()=='true', same_site='lax', max_age=604800)
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')

@contextmanager
def db():
    conn=sqlite3.connect(DB,timeout=20)
    conn.row_factory=sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally: conn.close()

with db() as c:
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('CREATE TABLE IF NOT EXISTS signals (id INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT UNIQUE NOT NULL, received_at TEXT NOT NULL, payload TEXT NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS subscriptions (endpoint TEXT PRIMARY KEY, subscription TEXT NOT NULL)')

def logged(req): return req.session.get('authenticated') is True

def require_login(req):
    if not logged(req): raise HTTPException(401,'Login required')

class Login(BaseModel): password:str
class Subscription(BaseModel): endpoint:str; keys:dict

@app.get('/')
def index(): return FileResponse(BASE/'static'/'index.html')

@app.get('/health')
def health(): return {'status':'ok'}

@app.post('/api/login')
def login(data:Login,request:Request):
    if not hmac.compare_digest(data.password,PASSWORD): raise HTTPException(401,'Invalid password')
    request.session['authenticated']=True
    return {'ok':True}

@app.post('/api/logout')
def logout(request:Request):
    request.session.clear(); return {'ok':True}

@app.get('/api/me')
def me(request:Request): return {'authenticated':logged(request),'vapidPublicKey':os.getenv('VAPID_PUBLIC_KEY','') if logged(request) else ''}

@app.get('/api/signals')
def signals(request:Request):
    require_login(request)
    with db() as c:
        rows=c.execute('SELECT payload,received_at FROM signals ORDER BY id DESC LIMIT 100').fetchall()
    return [{'received_at':r['received_at'],**json.loads(r['payload'])} for r in rows]

@app.post('/api/subscribe')
def subscribe(data:Subscription,request:Request):
    require_login(request)
    if not data.endpoint.startswith('https://') or not all(k in data.keys for k in ('p256dh','auth')):
        raise HTTPException(400,'Invalid push subscription')
    sub=data.model_dump()
    with db() as c:
        c.execute('INSERT OR REPLACE INTO subscriptions(endpoint,subscription) VALUES (?,?)',(data.endpoint,json.dumps(sub)))
    return {'ok':True}

@app.post('/api/webhook/{token}')
async def webhook(token:str,request:Request):
    if not hmac.compare_digest(token,TOKEN): raise HTTPException(403,'Invalid token')
    if int(request.headers.get('content-length','0') or 0)>8192: raise HTTPException(413,'Payload too large')
    body=await request.body()
    if len(body)>8192: raise HTTPException(413,'Payload too large')
    try: data=json.loads(body)
    except Exception: raise HTTPException(400,'JSON required')
    if not isinstance(data,dict): raise HTTPException(400,'JSON object required')
    side=str(data.get('side','')).upper()
    if side not in ('BUY','SELL'): raise HTTPException(400,'side must be BUY or SELL')
    event_id=str(data.get('event_id',''))[:160]
    if not event_id: raise HTTPException(400,'event_id required')
    symbol=str(data.get('symbol','XAUUSD'))[:32]
    mode=str(data.get('mode','UNKNOWN'))[:40]
    try: entry=float(data['entry'])
    except (ValueError,TypeError,KeyError): raise HTTPException(400,'Numeric entry required')
    if not (0<entry<1e9): raise HTTPException(400,'Invalid entry')
    clean={'event_id':event_id,'side':side,'symbol':symbol,'mode':mode,'entry':entry,'time':str(data.get('time',''))[:80]}
    for field in ('sl','tp1','tp2','tp3','tp4','tp5','runner','final','bonus'):
        val=data.get(field)
        if val is not None and val!='':
            try: clean[field]=float(val)
            except (ValueError,TypeError): raise HTTPException(400,f'Invalid {field}')
    with db() as c:
        cur=c.execute('INSERT OR IGNORE INTO signals(event_id,received_at,payload) VALUES (?,?,?)',(event_id,datetime.now(timezone.utc).isoformat(),json.dumps(clean)))
        inserted=cur.rowcount>0
    if inserted: send_push(clean)
    return {'ok':True,'new':inserted}

def send_push(data):
    private=os.getenv('VAPID_PRIVATE_KEY','')
    public=os.getenv('VAPID_PUBLIC_KEY','')
    subject=os.getenv('VAPID_SUBJECT','')
    if not (private and public and subject): return
    with db() as c: subs=c.execute('SELECT endpoint,subscription FROM subscriptions').fetchall()
    for s in subs:
        try:
            webpush(subscription_info=json.loads(s['subscription']),data=json.dumps({'title':f"{data['side']} NOW • {data['symbol']}",'body':f"Entry {data['entry']} • {data['mode']}",'url':'/'}),vapid_private_key=private,vapid_claims={'sub':subject},ttl=120)
        except WebPushException as e:
            if getattr(getattr(e,'response',None),'status_code',None) in (404,410):
                with db() as c: c.execute('DELETE FROM subscriptions WHERE endpoint=?',(s['endpoint'],))
        except Exception as e: print('Push error:',type(e).__name__)
