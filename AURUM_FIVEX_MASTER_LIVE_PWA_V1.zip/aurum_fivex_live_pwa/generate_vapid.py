from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
import base64
from pathlib import Path
key=ec.generate_private_key(ec.SECP256R1())
Path('vapid_private.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
public=key.public_key().public_bytes(serialization.Encoding.X962,serialization.PublicFormat.UncompressedPoint)
print('VAPID_PRIVATE_KEY=vapid_private.pem')
print('VAPID_PUBLIC_KEY='+base64.urlsafe_b64encode(public).rstrip(b'=').decode())
print('Keep vapid_private.pem private and persistent; never commit it to a public repository.')
