# AURUM FIVEX MASTER — Live PWA V1

## Requirements
Python 3.11+, HTTPS hosting with persistent storage, TradingView plan supporting webhook alerts, and iOS 16.4+ for Home Screen Web Push.

## Local setup (Windows PowerShell)
1. Extract the ZIP and open PowerShell in the project directory.
2. `py -m venv .venv`
3. `.\.venv\Scripts\Activate.ps1`
4. `pip install -r requirements.txt`
5. `python generate_vapid.py`
6. Copy `.env.example` to `.env`. Set APP_PASSWORD, WEBHOOK_TOKEN, SESSION_SECRET to three DIFFERENT strong random strings (at least 24 characters). Set VAPID_PRIVATE_KEY and VAPID_PUBLIC_KEY from step 5 and VAPID_SUBJECT to a working `mailto:` address. Do not publish .env or private key.
7. `uvicorn main:app --host 127.0.0.1 --port 8000`
8. Visit `http://127.0.0.1:8000` to test login. iPhone push requires public HTTPS.

## Deployment
Deploy the directory to a Python-capable host using `uvicorn main:app --host 0.0.0.0 --port ${PORT:-8000}` on Linux, behind HTTPS reverse proxy. Use a persistent disk for `DB_PATH` and the VAPID private key. Set `COOKIE_SECURE=true` in production. Do not deploy to an ephemeral filesystem if history/subscriptions must persist. Set all secrets as protected environment variables. Use one app worker for this starter SQLite implementation. Configure backups, monitoring, and rate limits at the edge before public use. If you use a reverse proxy, ensure HTTPS and cookie forwarding work correctly.

## TradingView alert integration
Webhook URL: `https://YOUR_DOMAIN/api/webhook/YOUR_WEBHOOK_TOKEN`
Alert body must be valid JSON, e.g.:
```
{"event_id":"XAUUSD-5-2026-11-12T10:30:00Z-BUY","side":"BUY","symbol":"XAUUSD","mode":"FAST+","entry":4010.2,"sl":3998.2,"tp1":4014.4,"tp2":4018.6,"time":"2026-11-12T10:30:00Z"}
```
Use a unique event_id for every distinct signal, and reuse it on webhook retries. Duplicate event_id is ignored. Price fields are illustrative. The Pine Script needs to construct this JSON from the REAL BUY NOW/SELL NOW conditions after candle close. TradingView webhook requires 2FA and a supported plan. Never include broker credentials in the alert body. The secret token in the URL is sensitive; rotate it if exposed. Avoid sharing webhook URLs in screenshots or logs.

## iPhone installation
Open your HTTPS site in Safari -> Share -> Add to Home Screen -> Open as Web App -> Add. Open the installed app, log in, and tap Enable Push. Grant notification permission. Notifications require HTTPS, a valid VAPID key pair and a persistent push subscription. Delivery is best-effort and may be delayed by device settings/network conditions. Keep the app installed and do not clear its website data.

## Security and limits
- This is a single-owner starter, not a multi-tenant commercial SaaS. Password login and session cookie; protect passwords and secrets.
- Webhook uses a long random URL token. Place edge rate limiting and request logging protections in front of it.
- History is stored in SQLite and may disappear on ephemeral hosting.
- Push notifications are sent synchronously on webhook receipt; high traffic needs a background queue.
- Web Push may not be guaranteed or immediate; do not rely on notifications alone for time-critical trading.
- This starter does not connect to a broker, execute trades, calculate realized P&L, or compute weekly pips. It displays the data sent by the indicator.
- TradingView integration is not complete until the actual Pine Script alert logic is adapted and tested.
